#!/usr/bin/env bash
<<<<<<< HEAD
# Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
=======
>>>>>>> 94ad96f (first/init commit)
set -euo pipefail

LOG_FILE="logs/action.log"
mkdir -p logs

clear
echo "Action History"
echo "--------------"

if [ ! -f "$LOG_FILE" ]; then
  echo "Лог пока пуст."
  return 1
fi

# Показать последние 50 строк
tail -n 50 "$LOG_FILE"

echo
echo "--------------------------"
echo "Enter - продолжить, C - скопировать весь лог, Space - выйти"

read -r -n 1 -s action
echo

case $action in
  "")  return 1 ;;   # Enter → просто выход
  " ") return 1 ;;   # Space → выход
  "C"|"c")
       cat "$LOG_FILE" | xclip -selection clipboard 2>/dev/null || \
       cat "$LOG_FILE" | pbcopy 2>/dev/null || \
       echo "Скопировать не удалось (нет утилиты xclip/pbcopy). Содержимое выше."
       ;;
esac
