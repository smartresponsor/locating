<?php
declare(strict_types=1);
namespace SmartResponsor\Integration\Locator\Fallback;
use SmartResponsor\Contract\Locator\LocatorInterface;
use SmartResponsor\Model\Locator\AddressData;
use SmartResponsor\Model\Locator\GeoPoint;
final class FallbackLocator implements LocatorInterface{
  public function normalize(string $raw): AddressData{
    // dumb split
    $parts = array_map('trim', explode(',', $raw));
    $street = $parts[0] ?? ''; $city = $parts[1] ?? ''; $rest = $parts[2] ?? '';
    $region = ''; $postal = '';
    if ($rest !== ''){
      if (preg_match('~([A-Z]{2,})\s+(\S+)~', $rest, $m)){ $region=$m[1]; $postal=$m[2]; }
    }
    return new AddressData($street, $city, $region, $postal, '');
  }
  public function geocode(AddressData $a): GeoPoint{ return new GeoPoint(0.0,0.0); }
  public function reverse(GeoPoint $p): AddressData{ return new AddressData('','','','',''); }
}
