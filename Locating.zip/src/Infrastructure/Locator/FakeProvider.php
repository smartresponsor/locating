<?php
declare(strict_types=1);
/**
 * Copyright (c) 2025 Oleksandr Tishchenko / Marketing America Corp
 * SmartResponsor Canon: single-hyphen naming, mirror interfaces, singular names only.
 * Comments in English only. Postgres = Data, MySQL = Infrastructure.
 */

namespace App\Infrastructure\Locator;

use App\InfrastructureInterface\Locator\ProviderAdapterInterface;

final class FakeProvider implements ProviderAdapterInterface
{
    public function __construct(
        private string $name,
        private float $lat = 29.76,
        private float $lon = -95.37
    ) {
    }

    public function call(array $request): array
    {
        $q = (string)($request['q'] ?? 'unknown');

        return [
            'status' => 'ok',
            'q' => $q,
            'lat' => $this->lat,
            'lon' => $this->lon,
            'text' => $this->name . ' ' . $q,
        ];
    }
}
